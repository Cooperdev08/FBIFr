INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_fbi', 'FBI', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_fbi', 'FBI', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_fbi', 'FBI', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('fbi','FBI')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('fbi',0,'agent','Agent',20,'{}','{}'),
	('fbi',1,'agentsp','Agent-SP',40,'{}','{}'),
	('fbi',2,'chefop','Chef-OP',60,'{}','{}'),
	('fbi',3,'codirecteur','Co-Directeur',85,'{}','{}'),
	('fbi',4,'boss','Directeur',100,'{}','{}')
;

CREATE TABLE `fine_types` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`label` varchar(255) DEFAULT NULL,
	`amount` int(11) DEFAULT NULL,
	`category` int(11) DEFAULT NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO `fine_types` (label, amount, category) VALUES
	('Tir sur civil',2000,3),
	('Tir sur agent de l\'état Federal',25000,3),
	('Tentative de meurtre sur civil',3000,3),
	('Tentative de meurtre sur agent de l\'état Frederal',35000,3),
	('Meurtre sur civil',10000,3),
	('Meurte sur agent de l\'état Frederal',40000,3),
	
;
